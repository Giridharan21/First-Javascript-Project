$(document).ready(function(){
	var name;
	if(localStorage.getItem('username')!==null){
		alert('Taking to Product List');
		location.href='productList.html';
	}
	$('#username').focus();
	$('#reg').click(function(){
		location.href='register.html';
	});
	$('#but').click(function() {
		var temp = /^[a-zA-Z0-9]+$/ , temp2= /^[a-zA-Z0-9!@#$]+$/ , alpha=/^[a-zA-Z]+$/ , num = /^[0-9]+$/;
		name=document.getElementById('username').value;
		var pass=document.getElementById('password').value;
		if(!name||!pass){
			alert('Enter Username/Password');
			return false;
		}/*
		else if(name.length<5){
			alert('Username should be 5 characters Long');
			return false;
		}
		else if(pass.length<8){
			alert('Password should contain atleast 8 characters');
			return false;
		}
		else if((num.test(name))&&(!(alpha.test(name)))){
			alert('Username should contain atleast two alphabets');
		}
		else if(!(temp.test(name))){
			alert('Username should be in Alphanumeric Only!!');
			return false;
		}
		else if(!(temp2.test(pass))){
			alert('Password should contain followed symbols only !@#$');
			return false;
		}*/
		//name==='admin'&&
		else if(name==='admin'&&pass==='admin123'){
			localStorage.username=JSON.stringify(name);
			localStorage.Password=JSON.stringify(pass);
			location.href='productList.html';
		}
		else {
		if(localStorage.getItem('nameDB')!==null){
				var tempnameDB=JSON.parse(localStorage.nameDB);
			for(i=0;i<tempnameDB.length;i++){
				if(name===tempnameDB[i]&&(localStorage.getItem('passDB')!==null)){
					if(pass===JSON.parse(localStorage.getItem('passDB'))[i]){
						localStorage.username=JSON.stringify(name);
						localStorage.Password=JSON.stringify(pass);
						location.href='productList.html';
						return false;
					}
					else{
						alert('wrong Password');
						return false;
					}
				}
			}
			alert('User Not exits!! ');
		}
			alert('Register to Login!!');
		}
	});
	$('#username,#password').keypress(function(e){
		if(e.which==13)
			$('#but').click();
	});
});